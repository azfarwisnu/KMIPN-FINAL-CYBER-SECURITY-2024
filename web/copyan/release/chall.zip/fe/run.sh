docker build -t fe .
docker run -p 8085:80 -d fe