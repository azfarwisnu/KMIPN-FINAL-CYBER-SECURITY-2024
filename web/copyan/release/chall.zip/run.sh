docker build -t challpass .
docker run -p 8084:3300 -d challpass