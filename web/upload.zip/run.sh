docker build -t upchall .
docker run -it --rm -d -p 8086:80 upchall